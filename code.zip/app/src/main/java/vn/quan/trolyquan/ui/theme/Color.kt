package vn.quan.trolyquan.ui.theme

import androidx.compose.ui.graphics.Color

// Nền tối sang trọng (Obsidian & Midnight Cyber)
val ObsidianBg = Color(0xFF06080E)
val DeepSpaceSurface = Color(0xFF0D121E)
val GlassCardBg = Color(0xCC131A2C)
val GlassCardElevated = Color(0xE61A233A)
val GlassBorderSubtle = Color(0x3364DFDF)

// Màu nhấn Neon thế hệ mới
val NeonCyan = Color(0xFF00F5D4)
val NeonSky = Color(0xFF00BBF9)
val ElectricViolet = Color(0xFF9D4EDD)
val NeonMagenta = Color(0xFFF72585)
val HotAmber = Color(0xFFFF9E00)
val EmeraldSuccess = Color(0xFF06D6A0)
val CrimsonAlert = Color(0xFFFF2A85)

// Văn bản phân cấp rõ ràng
val TextPrimary = Color(0xFFF3F6FC)
val TextSecondary = Color(0xFFA9B4C9)
val TextMuted = Color(0xFF6C7A96)
