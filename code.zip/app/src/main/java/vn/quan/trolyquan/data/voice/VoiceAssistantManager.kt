package vn.quan.trolyquan.data.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale
import java.util.UUID
import kotlin.math.sin
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Quản lý hội thoại giọng nói hai chiều Tiếng Việt (vi-VN):
 * - SpeechRecognizer: Nhận diện giọng nói tiếng Việt thời gian thực, đo biên độ sóng âm (RMS dB).
 * - TextToSpeech: Đọc câu trả lời của Quân, tự động ưu tiên tìm giọng Nam tiếng Việt tự nhiên,
 *   cho phép ngắt lời tức thì (Barge-In) khi người dùng chạm Micro.
 */
class VoiceAssistantManager(
    private val context: Context,
    private val onFinalSpeechResult: (String) -> Unit,
    private val onSpeechErrorEvent: (String) -> Unit,
    private val onTtsFinishedEvent: () -> Unit
) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    private val _audioAmplitude = MutableStateFlow(0.08f)
    val audioAmplitude: StateFlow<Float> = _audioAmplitude.asStateFlow()

    private val _ttsReady = MutableStateFlow(false)
    val ttsReady: StateFlow<Boolean> = _ttsReady.asStateFlow()

    private val _availableVietnameseVoices = MutableStateFlow<List<String>>(emptyList())
    val availableVietnameseVoices: StateFlow<List<String>> = _availableVietnameseVoices.asStateFlow()

    private val _selectedVoiceSummary = MutableStateFlow("Đang khởi tạo giọng đọc tiếng Việt...")
    val selectedVoiceSummary: StateFlow<String> = _selectedVoiceSummary.asStateFlow()

    private var ttsPulseTick = 0f
    private val ttsWaveAnimator = object : Runnable {
        override fun run() {
            if (_isSpeaking.value) {
                ttsPulseTick += 0.35f
                val simulated = (0.35f + 0.45f * kotlin.math.abs(sin(ttsPulseTick)) +
                    0.20f * kotlin.math.abs(sin(ttsPulseTick * 2.3f))).coerceIn(0.15f, 1.0f)
                _audioAmplitude.value = simulated
                mainHandler.postDelayed(this, 40L)
            } else {
                _audioAmplitude.value = 0.08f
            }
        }
    }

    init {
        initializeTextToSpeech()
    }

    private fun initializeTextToSpeech() {
        textToSpeech = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val viLocale = Locale("vi", "VN")
                val result = textToSpeech?.setLanguage(viLocale)
                val supported = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
                _ttsReady.value = supported
                configureBestVietnameseMaleVoice(preferredVoiceName = "")
                setupUtteranceListener()
            } else {
                _ttsReady.value = false
                _selectedVoiceSummary.value = "Không khởi tạo được TextToSpeech trên thiết bị này"
            }
        }
    }

    /**
     * Quét toàn bộ danh sách Voice của Google TTS / Samsung TTS để ưu tiên giọng Nam tiếng Việt
     * (thường có mã `vi-vn-x-vid-local`, `vi-vn-x-vid-network`, `vi-vn-x-vie-local`, hoặc chứa từ khóa male/vid/vie).
     */
    fun configureBestVietnameseMaleVoice(
        preferredVoiceName: String,
        pitch: Float = 0.90f,
        rate: Float = 1.05f
    ) {
        val tts = textToSpeech ?: return
        tts.setPitch(pitch.coerceIn(0.5f, 1.6f))
        tts.setSpeechRate(rate.coerceIn(0.6f, 1.8f))

        try {
            val allVoices: Set<Voice> = tts.voices ?: emptySet()
            val viVoices = allVoices.filter { voice ->
                voice.locale.language.equals("vi", ignoreCase = true)
            }.sortedBy { it.name }

            _availableVietnameseVoices.value = viVoices.map { it.name }

            // 1. Nếu người dùng đã chọn cụ thể 1 voice trong Cài đặt
            val userChosen = if (preferredVoiceName.isNotBlank()) {
                viVoices.firstOrNull { it.name.equals(preferredVoiceName, ignoreCase = true) }
            } else null

            // 2. Tự động ưu tiên giọng Nam tiếng Việt của Google Speech Services
            // Trên Android Google TTS, "vi-vn-x-vid" và "vi-vn-x-vie" là các giọng nam trầm rõ.
            val autoMaleVoice = viVoices.firstOrNull { v ->
                val n = v.name.lowercase(Locale.ROOT)
                n.contains("vid-local") || n.contains("vid-network") ||
                    n.contains("vie-local") || n.contains("vie-network") ||
                    n.contains("male") || n.contains("nam")
            } ?: viVoices.firstOrNull { !it.isNetworkConnectionRequired }
                ?: viVoices.firstOrNull()

            val chosenVoice = userChosen ?: autoMaleVoice
            if (chosenVoice != null) {
                tts.voice = chosenVoice
                _selectedVoiceSummary.value = "Giọng đọc: ${chosenVoice.name} (Pitch ${"%.2f".format(pitch)}x)"
            } else {
                tts.language = Locale("vi", "VN")
                _selectedVoiceSummary.value = "Giọng mặc định Tiếng Việt (vi-VN • Pitch ${"%.2f".format(pitch)}x)"
            }
        } catch (_: Exception) {
            _selectedVoiceSummary.value = "Giọng mặc định Tiếng Việt (vi-VN)"
        }
    }

    private fun setupUtteranceListener() {
        textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                _isSpeaking.value = true
                mainHandler.post(ttsWaveAnimator)
            }

            override fun onDone(utteranceId: String?) {
                _isSpeaking.value = false
                _audioAmplitude.value = 0.08f
                mainHandler.post { onTtsFinishedEvent() }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                _isSpeaking.value = false
                _audioAmplitude.value = 0.08f
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                _isSpeaking.value = false
                _audioAmplitude.value = 0.08f
            }
        })
    }

    /**
     * Đọc thành tiếng câu trả lời của Quân. Nếu đang nghe mic thì tự ngắt mic trước khi nói.
     */
    fun speak(
        text: String,
        pitch: Float = 0.90f,
        rate: Float = 1.05f,
        preferredVoiceName: String = ""
    ) {
        val cleanText = text
            .replace(Regex("[*_`#~>]"), "")
            .trim()
        if (cleanText.isBlank()) return

        if (_isListening.value) {
            stopListening()
        }

        val tts = textToSpeech ?: return
        if (!_ttsReady.value) return

        configureBestVietnameseMaleVoice(
            preferredVoiceName = preferredVoiceName,
            pitch = pitch,
            rate = rate
        )

        val utteranceId = UUID.randomUUID().toString()
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
        }
        tts.speak(cleanText, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }

    /**
     * Ngắt lời Quân ngay lập tức (Barge-in) khi người dùng bấm nút Ngắt lời hoặc bấm Micro.
     */
    fun stopSpeaking() {
        try {
            if (textToSpeech?.isSpeaking == true || _isSpeaking.value) {
                textToSpeech?.stop()
            }
        } catch (_: Exception) {
        } finally {
            _isSpeaking.value = false
            _audioAmplitude.value = 0.08f
        }
    }

    /**
     * Bắt đầu thu âm và nhận diện giọng nói tiếng Việt (vi-VN).
     * Nếu Quân đang nói thì tự động ngắt lời Quân ngay lập tức để nghe người dùng!
     */
    fun startListening() {
        mainHandler.post {
            stopSpeaking()

            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                onSpeechErrorEvent(
                    "Thiết bị chưa cài đặt dịch vụ nhận diện giọng nói (Google Speech Services). Bạn vẫn có thể gõ văn bản bên dưới!"
                )
                return@post
            }

            try {
                if (speechRecognizer == null) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                        setRecognitionListener(createRecognitionListener())
                    }
                } else {
                    speechRecognizer?.cancel()
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "vi-VN")
                    putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
                }

                _partialTranscript.value = ""
                _isListening.value = true
                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                _isListening.value = false
                onSpeechErrorEvent("Không thể bật Micro: ${e.localizedMessage ?: "Lỗi SpeechRecognizer"}")
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
            } catch (_: Exception) {
            } finally {
                _isListening.value = false
                _audioAmplitude.value = 0.08f
            }
        }
    }

    private fun createRecognitionListener(): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _isListening.value = true
                _partialTranscript.value = "Đang nghe anh em nói..."
            }

            override fun onBeginningOfSpeech() {
                _isListening.value = true
            }

            override fun onRmsChanged(rmsdB: Float) {
                // Chuẩn hóa rmsdB (-2..12 dB) sang biên độ 0.10..1.0 cho vòng sóng âm Neon
                val normalized = ((rmsdB + 2f) / 12f).coerceIn(0.10f, 1.0f)
                _audioAmplitude.value = normalized
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _isListening.value = false
                _audioAmplitude.value = 0.08f
            }

            override fun onError(error: Int) {
                _isListening.value = false
                _audioAmplitude.value = 0.08f
                _partialTranscript.value = ""
                val message = mapSpeechErrorToVietnamese(error)
                onSpeechErrorEvent(message)
            }

            override fun onResults(results: Bundle?) {
                _isListening.value = false
                _audioAmplitude.value = 0.08f
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val bestText = matches?.firstOrNull()?.trim().orEmpty()
                _partialTranscript.value = ""
                if (bestText.isNotBlank()) {
                    onFinalSpeechResult(bestText)
                } else {
                    onSpeechErrorEvent("Quân chưa nghe rõ câu vừa rồi, ông nói lại to hơn chút nhé!")
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val partialList = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = partialList?.firstOrNull()?.trim().orEmpty()
                if (text.isNotBlank()) {
                    _partialTranscript.value = text
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    private fun mapSpeechErrorToVietnamese(errorCode: Int): String = when (errorCode) {
        SpeechRecognizer.ERROR_AUDIO ->
            "Lỗi thu âm từ Micro (ERROR_AUDIO). Kiểm tra xem có ứng dụng nào đang chiếm quyền Micro không nhé!"
        SpeechRecognizer.ERROR_CLIENT ->
            "Đã dừng thu âm theo yêu cầu người dùng."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
            "Chưa cấp quyền Micro (RECORD_AUDIO). Hãy bấm cho phép quyền thu âm để nói chuyện với Quân!"
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
            "Lỗi mạng khi nhận diện giọng nói. Hãy kiểm tra kết nối Wi-Fi/4G hoặc tải gói tiếng Việt Offline trong Google Voice!"
        SpeechRecognizer.ERROR_NO_MATCH ->
            "Không nhận diện được câu nói (ERROR_NO_MATCH). Ông nói rõ tiếng Việt hơn chút cho Quân nghe nhé!"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
            "Bộ nhận diện giọng nói đang bận, đợi 1 giây rồi bấm lại nhé!"
        SpeechRecognizer.ERROR_SERVER ->
            "Máy chủ nhận diện giọng nói phản hồi lỗi. Thử nói lại hoặc gõ văn bản nhé!"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
            "Chưa nghe thấy tiếng động nào từ Micro (Timeout). Bấm nút Micro rồi nói luôn nhé ông bạn!"
        else ->
            "Lỗi nhận diện giọng nói (Mã: $errorCode). Bạn có thể thử lại hoặc nhập văn bản."
    }

    fun release() {
        mainHandler.removeCallbacksAndMessages(null)
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (_: Exception) {
        }
        try {
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            textToSpeech = null
        } catch (_: Exception) {
        }
    }
}
