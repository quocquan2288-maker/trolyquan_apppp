package vn.quan.trolyquan.data.ai

import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import vn.quan.trolyquan.domain.model.AiProviderType
import vn.quan.trolyquan.domain.model.AiSettings
import vn.quan.trolyquan.domain.model.ChatMessage
import vn.quan.trolyquan.domain.model.CommandType
import vn.quan.trolyquan.domain.model.InstalledAppInfo
import vn.quan.trolyquan.domain.model.MessageSender
import vn.quan.trolyquan.domain.model.SystemCommand

/**
 * Dịch vụ kết nối trực tiếp tới Google Gemini API (chính thức) hoặc OpenAI/Groq API.
 * Có cơ chế bảo vệ lỗi mất mạng, giới hạn tốc độ (HTTP 429), sai API key (HTTP 401/403),
 * lỗi máy chủ (HTTP 5xx) và tự động kết hợp LocalCommandFallbackParser.
 */
class AiApiService {

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    data class AiTurnResponse(
        val replyText: String,
        val moodTag: String,
        val command: SystemCommand,
        val usedOfflineFallback: Boolean = false,
        val errorDiagnostic: String? = null
    )

    suspend fun generateAssistantTurn(
        userText: String,
        conversationHistory: List<ChatMessage>,
        settings: AiSettings,
        installedApps: List<InstalledAppInfo>,
        torchCurrentlyOn: Boolean,
        currentVolumePercent: Int
    ): AiTurnResponse = withContext(Dispatchers.IO) {
        val localParsed = LocalCommandFallbackParser.parseUserText(userText)

        // Nếu người dùng chưa cấu hình API Key:
        // - Nếu là lệnh điều khiển hệ thống rõ ràng -> Thực thi thật ngay lập tức!
        // - Nếu là câu trò chuyện tự do -> Trả lời theo phong cách Quân và nhắc cấu hình API Key.
        if (settings.apiKey.isBlank()) {
            return@withContext AiTurnResponse(
                replyText = localParsed.replyText,
                moodTag = localParsed.moodTag,
                command = localParsed.command,
                usedOfflineFallback = true,
                errorDiagnostic = if (localParsed.isConfidentSystemCommand) null
                else "Chưa cấu hình API Key trong mục Cài Đặt (đang dùng bộ xử lý nội bộ)."
            )
        }

        val systemPrompt = PersonaPromptBuilder.buildSystemPrompt(
            installedApps = installedApps,
            allowSlangAndRoast = settings.allowSlangAndRoast,
            torchCurrentlyOn = torchCurrentlyOn,
            currentVolumePercent = currentVolumePercent
        )

        try {
            val rawModelJson = when (settings.provider) {
                AiProviderType.GEMINI -> callGeminiApi(
                    userText = userText,
                    history = conversationHistory,
                    systemPrompt = systemPrompt,
                    settings = settings
                )
                AiProviderType.GROQ, AiProviderType.OPENAI_COMPATIBLE -> callOpenAiCompatibleApi(
                    userText = userText,
                    history = conversationHistory,
                    systemPrompt = systemPrompt,
                    settings = settings
                )
            }

            val parsed = parseStructuredJsonResponse(rawModelJson, localParsed)
            return@withContext parsed
        } catch (e: ApiHttpException) {
            handleHttpException(e, localParsed)
        } catch (e: UnknownHostException) {
            handleNetworkFailure("Mất kết nối Internet (Không phân giải được máy chủ)", localParsed)
        } catch (e: SocketTimeoutException) {
            handleNetworkFailure("Máy chủ AI phản hồi quá thời gian chờ (Timeout)", localParsed)
        } catch (e: IOException) {
            handleNetworkFailure("Lỗi đường truyền mạng: ${e.localizedMessage ?: "IOException"}", localParsed)
        } catch (e: Exception) {
            handleNetworkFailure("Lỗi xử lý dữ liệu AI: ${e.localizedMessage ?: "Unknown"}", localParsed)
        }
    }

    private fun callGeminiApi(
        userText: String,
        history: List<ChatMessage>,
        systemPrompt: String,
        settings: AiSettings
    ): String {
        val baseUrl = settings.baseUrl.trimEnd('/')
        val model = settings.modelName.ifBlank { "gemini-2.5-flash" }
        val url = "$baseUrl/models/$model:generateContent?key=${settings.apiKey}"

        val contentsArray = JSONArray()
        // Đưa tối đa 14 lượt hội thoại gần nhất để Quân nhớ rõ ngữ cảnh
        val recentTurns = history.takeLast(14)
        for (msg in recentTurns) {
            if (msg.text.isBlank() || msg.sender == MessageSender.SYSTEM) continue
            val role = if (msg.sender == MessageSender.USER) "user" else "model"
            val partText = if (msg.sender == MessageSender.QUAN) {
                JSONObject().apply {
                    put("reply", msg.text)
                    put("mood", msg.moodTag)
                    put("action", JSONObject().put("type", "NONE"))
                }.toString()
            } else {
                msg.text
            }
            val turnObj = JSONObject().apply {
                put("role", role)
                put("parts", JSONArray().put(JSONObject().put("text", partText)))
            }
            contentsArray.put(turnObj)
        }

        // Thêm câu lệnh hiện tại của người dùng
        contentsArray.put(
            JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", userText)))
            }
        )

        val payload = JSONObject().apply {
            put(
                "systemInstruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", systemPrompt))
                )
            )
            put("contents", contentsArray)
            put(
                "generationConfig",
                JSONObject().apply {
                    put("temperature", 0.75)
                    put("responseMimeType", "application/json")
                }
            )
        }

        val request = Request.Builder()
            .url(url)
            .post(payload.toString().toRequestBody(jsonMediaType))
            .header("Content-Type", "application/json")
            .header("x-goog-api-key", settings.apiKey)
            .apply {
                if (settings.apiKey.startsWith("AQ.")) {
                    header("Authorization", "Bearer ${settings.apiKey}")
                }
            }
            .build()

        httpClient.newCall(request).execute().use { response ->
            val bodyString = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw ApiHttpException(response.code, extractApiErrorDetail(bodyString))
            }
            val root = JSONObject(bodyString)
            val candidates = root.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                throw IOException("Gemini không trả về ứng viên câu trả lời nào.")
            }
            val parts = candidates.getJSONObject(0)
                .optJSONObject("content")
                ?.optJSONArray("parts")
            return parts?.optJSONObject(0)?.optString("text").orEmpty()
        }
    }

    private fun callOpenAiCompatibleApi(
        userText: String,
        history: List<ChatMessage>,
        systemPrompt: String,
        settings: AiSettings
    ): String {
        val baseUrl = settings.baseUrl.trimEnd('/')
        val url = "$baseUrl/chat/completions"

        val messagesArray = JSONArray()
        messagesArray.put(
            JSONObject().apply {
                put("role", "system")
                put("content", systemPrompt)
            }
        )

        val recentTurns = history.takeLast(14)
        for (msg in recentTurns) {
            if (msg.text.isBlank() || msg.sender == MessageSender.SYSTEM) continue
            val role = if (msg.sender == MessageSender.USER) "user" else "assistant"
            val content = if (msg.sender == MessageSender.QUAN) {
                JSONObject().apply {
                    put("reply", msg.text)
                    put("mood", msg.moodTag)
                    put("action", JSONObject().put("type", "NONE"))
                }.toString()
            } else {
                msg.text
            }
            messagesArray.put(
                JSONObject().apply {
                    put("role", role)
                    put("content", content)
                }
            )
        }

        messagesArray.put(
            JSONObject().apply {
                put("role", "user")
                put("content", userText)
            }
        )

        val payload = JSONObject().apply {
            put("model", settings.modelName.ifBlank { settings.provider.defaultModel })
            put("messages", messagesArray)
            put("temperature", 0.75)
            put("response_format", JSONObject().put("type", "json_object"))
        }

        val request = Request.Builder()
            .url(url)
            .post(payload.toString().toRequestBody(jsonMediaType))
            .header("Authorization", "Bearer ${settings.apiKey}")
            .header("Content-Type", "application/json")
            .build()

        httpClient.newCall(request).execute().use { response ->
            val bodyString = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw ApiHttpException(response.code, extractApiErrorDetail(bodyString))
            }
            val root = JSONObject(bodyString)
            val choices = root.optJSONArray("choices")
            if (choices == null || choices.length() == 0) {
                throw IOException("API không trả về kết quả trong choices.")
            }
            return choices.getJSONObject(0)
                .optJSONObject("message")
                ?.optString("content")
                .orEmpty()
        }
    }

    private fun parseStructuredJsonResponse(
        rawText: String,
        localFallback: LocalCommandFallbackParser.ParsedDecision
    ): AiTurnResponse {
        val cleanedJson = rawText
            .trim()
            .removePrefix("```json")
            .removePrefix("```JSON")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()

        return try {
            val json = JSONObject(cleanedJson)
            val reply = json.optString("reply", "").ifBlank { localFallback.replyText }
            val mood = json.optString("mood", "THANG_THAN")
            val actionObj = json.optJSONObject("action")

            val aiCommand = if (actionObj != null) {
                val typeStr = actionObj.optString("type", "NONE").uppercase(Locale.ROOT)
                val cmdType = try {
                    CommandType.valueOf(typeStr)
                } catch (_: Exception) {
                    CommandType.NONE
                }
                SystemCommand(
                    type = cmdType,
                    target = actionObj.optString("target", ""),
                    stringValue = actionObj.optString("string_value", ""),
                    booleanValue = if (actionObj.has("boolean_value") && !actionObj.isNull("boolean_value")) {
                        actionObj.optBoolean("boolean_value")
                    } else null,
                    intValue = if (actionObj.has("int_value") && !actionObj.isNull("int_value")) {
                        actionObj.optInt("int_value")
                    } else null,
                    hour = if (actionObj.has("hour") && !actionObj.isNull("hour")) {
                        actionObj.optInt("hour")
                    } else null,
                    minute = if (actionObj.has("minute") && !actionObj.isNull("minute")) {
                        actionObj.optInt("minute")
                    } else null,
                    requiresConfirmation = actionObj.optBoolean(
                        "requires_confirmation",
                        cmdType == CommandType.CALL_NUMBER
                    )
                )
            } else {
                SystemCommand(type = CommandType.NONE)
            }

            // Nếu AI trả về NONE nhưng bộ phân tích lệnh nội bộ chắc chắn 100% là lệnh hệ thống
            val finalCommand = if (aiCommand.type == CommandType.NONE && localFallback.isConfidentSystemCommand) {
                localFallback.command
            } else {
                aiCommand
            }

            AiTurnResponse(
                replyText = reply,
                moodTag = mood,
                command = finalCommand,
                usedOfflineFallback = false
            )
        } catch (_: Exception) {
            // Trường hợp mô hình trả về văn bản thuần không bọc JSON
            AiTurnResponse(
                replyText = rawText.ifBlank { localFallback.replyText },
                moodTag = "THANG_THAN",
                command = if (localFallback.isConfidentSystemCommand) localFallback.command else SystemCommand(),
                usedOfflineFallback = false
            )
        }
    }

    private fun handleHttpException(
        e: ApiHttpException,
        localParsed: LocalCommandFallbackParser.ParsedDecision
    ): AiTurnResponse {
        val reason = when (e.statusCode) {
            400 -> "Yêu cầu không hợp lệ (HTTP 400): ${e.detail}"
            401, 403 -> "API Key không hợp lệ hoặc đã hết hạn (HTTP ${e.statusCode}). Hãy kiểm tra lại trong tab Cài Đặt."
            429 -> "Đã vượt quá giới hạn lượt gọi miễn phí mỗi phút (HTTP 429 - Rate Limit). Đợi vài giây rồi thử lại nhé!"
            in 500..599 -> "Máy chủ AI đang quá tải hoặc bảo trì (HTTP ${e.statusCode})."
            else -> "Lỗi HTTP ${e.statusCode}: ${e.detail}"
        }

        return if (localParsed.isConfidentSystemCommand) {
            AiTurnResponse(
                replyText = "${localParsed.replyText} (Lưu ý: API AI đang báo lỗi HTTP ${e.statusCode} nên Quân tự xử lý nội bộ luôn!)",
                moodTag = "NONG_TINH",
                command = localParsed.command,
                usedOfflineFallback = true,
                errorDiagnostic = reason
            )
        } else {
            AiTurnResponse(
                replyText = "Đệt, cáu thật sự! $reason Ông mở tab Cài Đặt kiểm tra lại giúp Quân nhé!",
                moodTag = "NONG_TINH",
                command = SystemCommand(type = CommandType.NONE),
                usedOfflineFallback = true,
                errorDiagnostic = reason
            )
        }
    }

    private fun handleNetworkFailure(
        diagnostic: String,
        localParsed: LocalCommandFallbackParser.ParsedDecision
    ): AiTurnResponse {
        return if (localParsed.isConfidentSystemCommand) {
            AiTurnResponse(
                replyText = "${localParsed.replyText} (Đang mất mạng nên Quân dùng bộ điều khiển nội bộ xử lý luôn cho ông!)",
                moodTag = "NHIET_TINH",
                command = localParsed.command,
                usedOfflineFallback = true,
                errorDiagnostic = diagnostic
            )
        } else {
            AiTurnResponse(
                replyText = "Mạng mẽo chập chờn kiểu gì ấy ông ơi ($diagnostic)! Mấy lệnh điều khiển máy như 'Mở TikTok', 'Bật đèn pin', 'Tăng âm lượng' thì tôi vẫn làm ngay được, chứ chém gió AI thì kiểm tra lại Wi-Fi/4G giúp tôi cái!",
                moodTag = "NONG_TINH",
                command = SystemCommand(type = CommandType.NONE),
                usedOfflineFallback = true,
                errorDiagnostic = diagnostic
            )
        }
    }

    private fun extractApiErrorDetail(bodyString: String): String {
        return try {
            val json = JSONObject(bodyString)
            json.optJSONObject("error")?.optString("message")
                ?: json.optString("message")
                ?: bodyString.take(140)
        } catch (_: Exception) {
            bodyString.take(140)
        }
    }

    private class ApiHttpException(val statusCode: Int, val detail: String) : IOException(detail)
}
