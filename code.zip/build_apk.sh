#!/usr/bin/env bash
set -e

echo "=========================================================="
echo "   XÂY DỰNG APK TRỢ LÝ QUÂN (KOTLIN + JETPACK COMPOSE)    "
echo "=========================================================="

if ! command -v java &> /dev/null; then
    echo "[LỖI] Chưa tìm thấy JDK 17. Vui lòng cài đặt JDK 17 hoặc mở dự án bằng Android Studio."
    exit 1
fi

if [ -f "./gradlew" ]; then
    chmod +x ./gradlew
    ./gradlew assembleDebug
elif command -v gradle &> /dev/null; then
    gradle assembleDebug
else
    echo "[HƯỚNG DẪN] Mở thư mục dự án này trong Android Studio -> chọn Build > Build Bundle(s) / APK(s) > Build APK(s)."
    exit 1
fi

APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK_PATH" ]; then
    cp "$APK_PATH" "./TroLyQuan-v1.0-debug.apk"
    echo "[THÀNH CÔNG] File APK đã được tạo tại: ./TroLyQuan-v1.0-debug.apk"
    if command -v adb &> /dev/null; then
        echo "Đang kiểm tra thiết bị Android kết nối qua ADB..."
        if adb get-state 1>/dev/null 2>&1; then
            adb install -r "./TroLyQuan-v1.0-debug.apk"
            echo "[THÀNH CÔNG] Đã cài đặt TRỢ LÝ QUÂN lên điện thoại của bạn!"
        fi
    fi
fi
